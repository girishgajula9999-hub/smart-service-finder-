package com.example.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

/**
 * Handles creation of the Android Notification Channel and sending of native standard notifications.
 */
object NotificationHelper {
    private const val CHANNEL_ID = "key_events_channel"
    private const val CHANNEL_NAME = "Smart Service Finder Alerts"
    private const val CHANNEL_DESC = "Notifications for booking confirmations, provider arrivals, chat messages, and completions."
    private var isChannelCreated = false

    fun createNotificationChannel(context: Context) {
        if (isChannelCreated) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESC
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
            isChannelCreated = true
            Log.d("NotificationHelper", "Notification channel created: $CHANNEL_ID")
        }
    }

    fun createSystemNotification(context: Context, title: String, message: String, targetScreen: String) {
        // Ensure channel is initialized
        createNotificationChannel(context)

        // Clear intent leading back to MainActivity which handles target screen redirect
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("target_screen", targetScreen)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Using standard Android system icon, so it is guaranteed to compile flawlessly
        val iconRes = android.R.drawable.stat_notify_chat

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = System.currentTimeMillis().toInt()
        notificationManager.notify(notificationId, builder.build())
        Log.d("NotificationHelper", "Native OS Notification shown: title='$title', id=$notificationId")
    }
}

/**
 * Simulates a cloud backend dispatching push notification payloads (like standard Node.js/Python backend FCM trigger).
 * It sends structured push payloads to the client device.
 */
object NotificationBackendSimulator {

    fun dispatchBookingConfirmation(context: Context, bookingId: Int, providerName: String, date: String, slot: String) {
        val title = "Booking Confirmed! 🎉"
        val message = "Your appointment with $providerName is confirmed for $date ($slot)."
        Log.d("BackendSimulator", "FCM Backend dispatching push request to target: bookingId = $bookingId")
        
        // Pass payload through Client Receiver simulates both cellular/push pipeline
        NotificationReceiver.onMessageReceived(context, mapOf(
            "title" to title,
            "body" to message,
            "type" to "booking_confirmed",
            "booking_id" to bookingId.toString(),
            "target_screen" to "History"
        ))
    }

    fun dispatchProviderArrival(context: Context, bookingId: Int, providerName: String) {
        val title = "Provider Arrived! 🚗"
        val message = "Your service expert $providerName has arrived at your address."
        Log.d("BackendSimulator", "FCM Backend dispatching push request to target: bookingId = $bookingId")
        
        NotificationReceiver.onMessageReceived(context, mapOf(
            "title" to title,
            "body" to message,
            "type" to "provider_arrival",
            "booking_id" to bookingId.toString(),
            "target_screen" to "History"
        ))
    }

    fun dispatchMessageFromProvider(context: Context, bookingId: Int, providerName: String, chatText: String) {
        val title = "Message from $providerName 💬"
        val message = "\"$chatText\""
        Log.d("BackendSimulator", "FCM Backend dispatching push request to target: bookingId = $bookingId")
        
        NotificationReceiver.onMessageReceived(context, mapOf(
            "title" to title,
            "body" to message,
            "type" to "provider_message",
            "booking_id" to bookingId.toString(),
            "target_screen" to "Chat"
        ))
    }

    fun dispatchServiceCompletion(context: Context, bookingId: Int, providerName: String) {
        val title = "Service Completed Successfully! ✅"
        val message = "$providerName has finished the job. Thank you for using Smart Service Finder!"
        Log.d("BackendSimulator", "FCM Backend dispatching push request to target: bookingId = $bookingId")
        
        NotificationReceiver.onMessageReceived(context, mapOf(
            "title" to title,
            "body" to message,
            "type" to "service_completed",
            "booking_id" to bookingId.toString(),
            "target_screen" to "History"
        ))
    }
}

/**
 * Simulates the client-side Push Service Handler (like a React Native push listener hooks/FCM service).
 * This intercepts the payload, logs the payload receipt, updates local state, and routes to physical Android Tray Notification.
 */
object NotificationReceiver {
    private const val TAG = "PushNotificationClient"

    fun onMessageReceived(context: Context, data: Map<String, String>) {
        val title = data["title"] ?: "Smart Service Finder"
        val body = data["body"] ?: "Update on your service booking!"
        val targetScreen = data["target_screen"] ?: "Dashboard"

        Log.i(TAG, "==== REACT NATIVE & NATIVE MOBILE RECEIVER INVOCATION ====")
        Log.i(TAG, "Payload headers received: $data")
        Log.i(TAG, "FCM background notification handler successfully executed on client-side.")
        Log.i(TAG, "Target Redirection configured: AppScreen.$targetScreen")
        Log.i(TAG, "=========================================================")

        // Display Native OS banner alert
        NotificationHelper.createSystemNotification(context, title, body, targetScreen)
    }
}
