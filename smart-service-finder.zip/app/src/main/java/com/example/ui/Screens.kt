package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Booking
import com.example.data.Provider
import com.example.data.Review
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import android.os.Bundle
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// --- 1. SPLASH SCREEN ---
@Composable
fun SplashScreen(viewModel: ServiceViewModel) {
    var startAnimation by remember { mutableStateOf(false) }
    
    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2000)
        viewModel.navigateTo(AppScreen.Login)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF1E3A8A), Color(0xFF2563EB))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = startAnimation,
            enter = fadeIn(animationSpec = tween(1000)) + expandVertically(animationSpec = tween(1000))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Customized elegant logo representing service marketplace
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .background(Color.White.copy(alpha = 0.15f), CircleShape)
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.HomeRepairService,
                        contentDescription = "Builder Logo",
                        tint = Color.White,
                        modifier = Modifier.size(64.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "Smart Service Finder",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Find Trusted Professionals Nearby",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Light
                    ),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(48.dp))
                
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(36.dp)
                )
            }
        }
    }
}

// --- 2. LOGIN SCREEN ---
@Composable
fun LoginScreen(viewModel: ServiceViewModel) {
    val email by viewModel.loginEmail.collectAsState()
    val password by viewModel.loginPassword.collectAsState()
    val errorMsg by viewModel.loginError.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Logo Location",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Smart Service Finder",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            )
            
            Text(
                text = "Book certified professionals in minutes",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF64748B)
                ),
                modifier = Modifier.padding(bottom = 32.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "Sign In",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = { viewModel.loginEmail.value = it },
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, "Email Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { viewModel.loginPassword.value = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, "Lock Icon") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )

                    if (errorMsg.isNotEmpty()) {
                        Text(
                            text = errorMsg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { viewModel.performLogin() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("LOGIN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("New to Smart Service Finder? ", color = Color(0xFF64748B))
                Text(
                    text = "Register Here",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { viewModel.navigateTo(AppScreen.Register) }
                        .testTag("goto_register_button")
                )
            }
        }
    }
}

// --- 3. REGISTRATION SCREEN ---
@Composable
fun RegisterScreen(viewModel: ServiceViewModel) {
    val name by viewModel.registerName.collectAsState()
    val email by viewModel.registerEmail.collectAsState()
    val phone by viewModel.registerPhone.collectAsState()
    val password by viewModel.registerPassword.collectAsState()
    val address by viewModel.registerAddress.collectAsState()
    val errorMsg by viewModel.registerError.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Create Account",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            )
            
            Text(
                text = "Join our network of smart services",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF64748B)
                ),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { viewModel.registerName.value = it },
                        label = { Text("Name") },
                        leadingIcon = { Icon(Icons.Default.Person, "Name Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_name"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { viewModel.registerEmail.value = it },
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, "Email Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_email"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { viewModel.registerPhone.value = it },
                        label = { Text("Phone Number") },
                        leadingIcon = { Icon(Icons.Default.Phone, "Phone Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_phone"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { viewModel.registerPassword.value = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, "Lock Icon") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_password"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = address,
                        onValueChange = { viewModel.registerAddress.value = it },
                        label = { Text("Address / City Location") },
                        leadingIcon = { Icon(Icons.Default.Home, "Home Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_address"),
                        singleLine = true
                    )

                    if (errorMsg.isNotEmpty()) {
                        Text(
                            text = errorMsg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { viewModel.performRegister() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("register_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        )
                    ) {
                        Text("REGISTER & BOOK", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Already have an account? ", color = Color(0xFF64748B))
                Text(
                    text = "Sign In",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { viewModel.navigateTo(AppScreen.Login) }
                        .testTag("goto_login_button")
                )
            }
        }
    }
}

// --- COMMON BOTTOM NAVIGATION BAR ---
@Composable
fun AppBottomNavigation(current: AppScreen, onNavigate: (AppScreen) -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
        color = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column {
            // Minimal web-style border-t border-slate-100
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFFF1F5F9))
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val navItems = listOf(
                    NavTabItem("Home", Icons.Default.Home, AppScreen.Dashboard),
                    NavTabItem("Radar Map", Icons.Default.Map, AppScreen.Maps),
                    NavTabItem("AI Helper", Icons.Default.AutoAwesome, AppScreen.Chat),
                    NavTabItem("Bookings", Icons.Default.Assignment, AppScreen.History)
                )

                navItems.forEach { item ->
                    val isSelected = current == item.screen
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigate(item.screen) }
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (isSelected) Color(0xFF2563EB) else Color(0xFF94A3B8),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = item.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color(0xFF2563EB) else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

data class NavTabItem(
    val label: String, 
    val icon: androidx.compose.ui.graphics.vector.ImageVector, 
    val screen: AppScreen
)

// --- 4. HOME DASHBOARD ---
@Composable
fun DashboardScreen(viewModel: ServiceViewModel) {
    val user by viewModel.currentUser.collectAsState()
    val scoredList by viewModel.scoredProviders.collectAsState()
    val search by viewModel.searchText.collectAsState()
    val selectedCat by viewModel.selectedCategory.collectAsState()

    val categories = listOf(
        CategoryItem("Electrician", "🔧", Color(0xFFEFF6FF), Color(0xFF2563EB)),
        CategoryItem("Plumber", "🚰", Color(0xFFECFDF5), Color(0xFF10B981)),
        CategoryItem("Carpenter", "🪚", Color(0xFFFFF7ED), Color(0xFFF97316)),
        CategoryItem("AC Repair", "❄️", Color(0xFFF0FDF4), Color(0xFF22C55E)),
        CategoryItem("Painter", "🎨", Color(0xFFFAF5FF), Color(0xFFA855F7)),
        CategoryItem("Cleaning", "🧹", Color(0xFFFFF1F2), Color(0xFFF43F5E))
    )

    Scaffold(
        bottomBar = { AppBottomNavigation(AppScreen.Dashboard) { viewModel.navigateTo(it) } },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(AppScreen.Chat) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.AutoAwesome, "Ask AI Helper")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(innerPadding)
        ) {
            // Header: Clean Utility Design with white background, rounded bottom corners, and subtle shadow
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                    .background(Color.White)
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Small elegant "SF" logo card representing Smart Service Finder
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(Color(0xFF2563EB), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "SF",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Column(
                                modifier = Modifier.clickable { viewModel.navigateTo(AppScreen.Maps) }
                            ) {
                                Text(
                                    text = "CURRENT LOCATION",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF94A3B8),
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.8.sp
                                    )
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Bengaluru (Simulated)",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = Color(0xFF1E293B),
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "▼",
                                        color = Color(0xFF2563EB),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                        
                        IconButton(
                            onClick = { viewModel.handleLogout() },
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFF1F5F9), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout Button",
                                tint = Color(0xFF475569),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Minimal Search Bar nested cleanly inside Header card
                    OutlinedTextField(
                        value = search,
                        onValueChange = { viewModel.onSearchChanged(it) },
                        placeholder = { Text("Search for plumbing, electrical...") },
                        leadingIcon = { Icon(Icons.Default.Search, "Search icon", tint = Color(0xFF94A3B8)) },
                        trailingIcon = {
                            if (search.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchChanged("") }) {
                                    Icon(Icons.Default.Close, "Clear search", tint = Color(0xFF94A3B8))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dashboard_search_input"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFFF8FAFC),
                            unfocusedContainerColor = Color(0xFFF8FAFC),
                            focusedBorderColor = Color(0xFF2563EB),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedTextColor = Color(0xFF1E293B),
                            unfocusedTextColor = Color(0xFF1E293B)
                        ),
                        singleLine = true
                    )
                }
            }

            // Body
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                Spacer(modifier = Modifier.height(20.dp))

                // Category row
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Text(
                        text = "Categories",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            letterSpacing = (-0.3).sp
                        ),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // "All" filter chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selectedCat == null) Color(0xFF2563EB) else Color.White)
                                .border(1.dp, if (selectedCat == null) Color.Transparent else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                                .clickable { viewModel.selectCategoryFilter(null) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "⚡ All Services",
                                color = if (selectedCat == null) Color.White else Color(0xFF1E293B),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        categories.forEach { c ->
                            val isSelected = selectedCat == c.name
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF2563EB) else c.bgColor)
                                    .border(1.dp, if (isSelected) Color.Transparent else Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                                    .clickable { viewModel.selectCategoryFilter(c.name) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(c.emoji, fontSize = 15.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        c.name,
                                        color = if (isSelected) Color.White else Color(0xFF1E293B),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Nearby Providers scored list
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recommended Experts",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                letterSpacing = (-0.3).sp
                            )
                        )
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF10B981).copy(alpha = 0.12f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "AI TOP RATED",
                                color = Color(0xFF10B981),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                    
                    Text(
                        text = "Ranked dynamically in real-time based on Rating, Experience, and Location distance",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B)),
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    if (scoredList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Inbox, "Empty providers Logo", tint = Color(0xFFCBD5E1), modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No providers found under criteria", color = Color(0xFF64748B))
                            }
                        }
                    } else {
                        scoredList.forEach { item ->
                            ProviderCard(item = item) {
                                viewModel.selectProviderForDetails(item.provider)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

data class CategoryItem(val name: String, val emoji: String, val bgColor: Color, val colorAccent: Color)

@Composable
fun ProviderCard(item: ScoredProvider, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("provider_item_${item.provider.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Elegant linear gradient avatar representing a premium professional silhouette
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFEFF6FF), Color(0xFFDBEAFE))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.provider.name.split(" ").mapNotNull { it.firstOrNull() }.joinToString("").take(2).uppercase(),
                    color = Color(0xFF2563EB),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.provider.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold, 
                            color = Color(0xFF0F172A),
                            letterSpacing = (-0.2).sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFFEF3C7))
                            .padding(horizontal = 5.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Star, "Rating Star", tint = Color(0xFFF59E0B), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${item.provider.rating}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF9A3412)
                        )
                    }
                }

                Text(
                    text = "${item.provider.serviceType} • ${item.provider.experience} yrs exp",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B))
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFECFDF5))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.provider.availability,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF047857)
                        )
                    }
                    
                    Text(
                        text = "₹${item.provider.price.toInt()} / visit",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold, 
                            color = Color(0xFF0F172A)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = String.format("%.1f km", item.distance),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                )
                Text(
                    text = "distance",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8), fontSize = 9.sp)
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                // Lightweight premium AI match percentage badge, matching our Clean spec
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF2563EB).copy(alpha = 0.08f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Match ${(item.score * 10).roundToInt()}",
                        fontSize = 10.sp,
                        color = Color(0xFF2563EB),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// --- GOOGLE MAPS INTERACTIVE VIEW CONTAINER ---
@Composable
fun GoogleMapViewContainer(
    modifier: Modifier = Modifier,
    userLat: Double,
    userLng: Double,
    providers: List<ScoredProvider>,
    activeMarker: ScoredProvider?,
    onMarkerClick: (ScoredProvider) -> Unit,
    onMapClick: (LatLng) -> Unit,
    onUserLocationDragged: (LatLng) -> Unit
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    val mapView = remember {
        MapView(context).apply {
            id = android.view.View.generateViewId()
        }
    }

    DisposableEffect(lifecycle, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(Bundle())
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
        }
    }

    AndroidView(
        factory = { mapView },
        modifier = modifier,
        update = { view ->
            view.getMapAsync { googleMap ->
                googleMap.clear()
                googleMap.uiSettings.isZoomControlsEnabled = true
                googleMap.uiSettings.isCompassEnabled = true
                
                val userLocation = LatLng(userLat, userLng)
                googleMap.addMarker(
                    MarkerOptions()
                        .position(userLocation)
                        .title("Your Location")
                        .snippet("📍 Drag me or tap anywhere to relocate!")
                        .draggable(true)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                )
                
                providers.forEach { scoredItem ->
                    val p = scoredItem.provider
                    val isSelected = activeMarker?.provider?.id == p.id
                    val markerColor = when (p.serviceType) {
                        "Electrician" -> BitmapDescriptorFactory.HUE_AZURE
                        "Plumber" -> BitmapDescriptorFactory.HUE_GREEN
                        "Carpenter" -> BitmapDescriptorFactory.HUE_ORANGE
                        "AC Repair" -> BitmapDescriptorFactory.HUE_CYAN
                        "Painter" -> BitmapDescriptorFactory.HUE_VIOLET
                        else -> BitmapDescriptorFactory.HUE_ROSE
                    }
                    
                    val selectedColor = BitmapDescriptorFactory.HUE_YELLOW
                    
                    val m = googleMap.addMarker(
                        MarkerOptions()
                            .position(LatLng(p.latitude, p.longitude))
                            .title("${p.name} (${p.serviceType})")
                            .snippet("★${p.rating} | ${p.experience} years | ₹${p.price.toInt()}")
                            .icon(BitmapDescriptorFactory.defaultMarker(if (isSelected) selectedColor else markerColor))
                    )
                    m?.tag = scoredItem
                }
                
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 14f))
                
                googleMap.setOnMarkerClickListener { marker ->
                    val data = marker.tag as? ScoredProvider
                    if (data != null) {
                        onMarkerClick(data)
                        true
                    } else if (marker.title == "Your Location") {
                        false
                    } else {
                        false
                    }
                }
                
                googleMap.setOnMapClickListener { latLng ->
                    onMapClick(latLng)
                }

                googleMap.setOnMarkerDragListener(object : GoogleMap.OnMarkerDragListener {
                    override fun onMarkerDragStart(marker: com.google.android.gms.maps.model.Marker) {}
                    override fun onMarkerDrag(marker: com.google.android.gms.maps.model.Marker) {}
                    override fun onMarkerDragEnd(marker: com.google.android.gms.maps.model.Marker) {
                        if (marker.title == "Your Location") {
                            onUserLocationDragged(marker.position)
                        }
                    }
                })
            }
        }
    )
}

// --- 5. HIGH FIDELITY INTERACTIVE CANVAS GOOGLE MAP SCREEN ---
@Composable
fun MapScreen(viewModel: ServiceViewModel) {
    val providers by viewModel.scoredProviders.collectAsState()
    val selectCat by viewModel.selectedCategory.collectAsState()
    val scope = rememberCoroutineScope()

    val userLatitude by viewModel.userLat.collectAsState()
    val userLongitude by viewModel.userLng.collectAsState()

    var activeMarker by remember { mutableStateOf<ScoredProvider?>(null) }
    var mapsEngineSelected by remember { mutableStateOf("GoogleMaps") }

    // Flat mapping math to project coordinates onto a 2D canvas container
    // We bind Bangalore coordinate boundaries: Lat 12.94 to 12.99, Lng 77.56 to 77.62
    // We scale bounds dynamically so users can drag user coordinates and see distances recalculate in real-time.
    val minLat = 12.94
    val maxLat = 13.00
    val minLng = 77.56
    val maxLng = 77.62

    val categoriesList = listOf("Electrician", "Plumber", "Carpenter", "AC Repair", "Painter", "Cleaning")

    Scaffold(
        bottomBar = { AppBottomNavigation(AppScreen.Maps) { viewModel.navigateTo(it) } }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF1F5F9))
                .padding(innerPadding)
        ) {
            // Interactive Controls Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Real-Time Location & Radar Map",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                    )
                    Text(
                        text = if (mapsEngineSelected == "GoogleMaps") 
                            "Live interactive Google Map showing nearby service specialists and your GPS coordinate marker."
                        else "Drag the user pin 📍 anywhere to simulate real-time distance sorting and score updates!",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B))
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))

                    // Mode Selection Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("GoogleMaps" to "🗺️ Google Maps Live", "Radar" to "📡 Radar Simulator").forEach { (engine, label) ->
                            val isSelected = mapsEngineSelected == engine
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) Color.White else Color.Transparent)
                                    .border(1.dp, if (isSelected) Color(0xFFCBD5E1) else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { mapsEngineSelected = engine }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color(0xFF1E293B) else Color(0xFF64748B)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Service markers description row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categoriesList.forEach { cat ->
                            val isSelected = selectCat == cat
                            val color = when (cat) {
                                "Electrician" -> Color(0xFF2563EB)
                                "Plumber" -> Color(0xFF10B981)
                                "Carpenter" -> Color(0xFFF97316)
                                "AC Repair" -> Color(0xFF22C55E)
                                "Painter" -> Color(0xFFA855F7)
                                else -> Color(0xFFF43F5E) // Cleaning
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) color.copy(alpha = 0.2f) else Color(0xFFF1F5F9))
                                    .border(1.dp, if (isSelected) color else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.selectCategoryFilter(if (isSelected) null else cat) }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                                }
                            }
                        }
                    }
                }
            }

            // Map Area Container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFE2E8F0))
                    .border(2.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
            ) {
                if (mapsEngineSelected == "GoogleMaps") {
                    GoogleMapViewContainer(
                        modifier = Modifier.fillMaxSize(),
                        userLat = userLatitude,
                        userLng = userLongitude,
                        providers = providers,
                        activeMarker = activeMarker,
                        onMarkerClick = { activeMarker = it },
                        onMapClick = { latLng ->
                            viewModel.updateUserCoordinates(latLng.latitude, latLng.longitude)
                        },
                        onUserLocationDragged = { latLng ->
                            viewModel.updateUserCoordinates(latLng.latitude, latLng.longitude)
                        }
                    )
                } else {
                    // Vector drawn stylized street background
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(key1 = true) {
                                // Touch mapping to allow clicking any provider on the static Canvas
                                // Based on bounding boxes
                            }
                    ) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Draw stylized map grid lines (streets)
                        val strokeBrush = Brush.linearGradient(listOf(Color(0xFFCBD5E1), Color(0xFFCBD5E1)))
                        // Grid lines vertical
                        for (x in 1..4) {
                            drawLine(
                                color = Color(0xFFF1F5F9),
                                start = Offset(canvasWidth * (x / 5f), 0f),
                                end = Offset(canvasWidth * (x / 5f), canvasHeight),
                                strokeWidth = 10f
                            )
                        }
                        // Grid lines horizontal
                        for (y in 1..4) {
                            drawLine(
                                color = Color(0xFFF1F5F9),
                                start = Offset(0f, canvasHeight * (y / 5f)),
                                end = Offset(canvasWidth, canvasHeight * (y / 5f)),
                                strokeWidth = 10f
                            )
                        }

                        // Diagonal ring road
                        drawLine(
                            color = Color(0xFFF1F5F9).copy(alpha = 0.8f),
                            start = Offset(0f, 0f),
                            end = Offset(canvasWidth, canvasHeight),
                            strokeWidth = 24f
                        )
                    }

                    // Render user coordinate marker as a floating draggable icon
                    // We calculate percent coordinates based on Bangalore limits
                    val userPercentX = (userLongitude - minLng) / (maxLng - minLng)
                    val userPercentY = 1.0 - ((userLatitude - minLat) / (maxLat - minLat)) // Invert Y for UI coords

                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val containerWidth = maxWidth.value
                        val containerHeight = maxHeight.value

                        // Draggable 📍 User Marker
                        val userX = (userPercentX * containerWidth).coerceIn(20.0, containerWidth.toDouble() - 20.0).dp
                        val userY = (userPercentY * containerHeight).coerceIn(20.0, containerHeight.toDouble() - 20.0).dp

                        Box(
                            modifier = Modifier
                                .offset(x = userX - 25.dp, y = userY - 25.dp)
                                .size(50.dp)
                                .pointerInput(key1 = true) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        // Scale drag density parameters to update lat/lng coordinates
                                        val deltaLat = -(dragAmount.y / containerHeight) * (maxLat - minLat)
                                        val deltaLng = (dragAmount.x / containerWidth) * (maxLng - minLng)
                                        viewModel.updateUserCoordinates(
                                            (userLatitude + deltaLat).coerceIn(minLat, maxLat),
                                            (userLongitude + deltaLng).coerceIn(minLng, maxLng)
                                        )
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            // Pulsating background
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFF2563EB).copy(alpha = 0.15f), CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(Color.White, CircleShape)
                                    .shadow(2.dp, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("📍", fontSize = 14.sp)
                            }
                        }

                        // Render providers as clickable markers
                        providers.forEach { scoredItem ->
                            val p = scoredItem.provider
                            val pPercentX = (p.longitude - minLng) / (maxLng - minLng)
                            val pPercentY = 1.0 - ((p.latitude - minLat) / (maxLat - minLat))

                            val pX = (pPercentX * containerWidth).coerceIn(20.0, containerWidth.toDouble() - 20.0).dp
                            val pY = (pPercentY * containerHeight).coerceIn(20.0, containerHeight.toDouble() - 20.0).dp

                            val markerBg = when (p.serviceType) {
                                "Electrician" -> Color(0xFF2563EB)
                                "Plumber" -> Color(0xFF10B981)
                                "Carpenter" -> Color(0xFFF97316)
                                "AC Repair" -> Color(0xFF22C55E)
                                "Painter" -> Color(0xFFA855F7)
                                else -> Color(0xFFF43F5E) // Cleaning
                            }

                            Box(
                                modifier = Modifier
                                    .offset(x = pX - 18.dp, y = pY - 18.dp)
                                    .size(36.dp)
                                    .shadow(4.dp, CircleShape)
                                    .background(
                                        if (activeMarker?.provider?.id == p.id) Color(0xFFF59E0B) else markerBg,
                                        CircleShape
                                    )
                                    .clickable {
                                        activeMarker = scoredItem
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (p.serviceType) {
                                        "Electrician" -> "⚡"
                                        "Plumber" -> "🚰"
                                        "Carpenter" -> "🔨"
                                        "AC Repair" -> "❄️"
                                        "Painter" -> "🎨"
                                        else -> "🧹"
                                    },
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Slide Up selected Active Marker Panel details
            AnimatedContent(
                targetState = activeMarker,
                transitionSpec = {
                    slideInVertically { height -> height } togetherWith slideOutVertically { height -> height }
                },
                label = "Active Marker detail slide"
            ) { marker ->
                if (marker != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .testTag("map_provider_detail_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFEFF6FF), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            marker.provider.name.first().toString().uppercase(),
                                            fontWeight = FontWeight.Bold, color = Color(0xFF2563EB)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = marker.provider.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${marker.provider.serviceType} • ★${marker.provider.rating} • ${marker.provider.experience}Y Exp",
                                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B))
                                        )
                                    }
                                }
                                IconButton(onClick = { activeMarker = null }) {
                                    Icon(Icons.Default.Close, "Dismiss Panel")
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Live Distance: ${String.format("%.2f km", marker.distance)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF2563EB), fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Estimated Visit Fee: ₹${marker.provider.price.toInt()}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF1E293B), fontWeight = FontWeight.Medium)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.selectProviderForDetails(marker.provider)
                                            viewModel.navigateTo(AppScreen.Chat)
                                            viewModel.sendChatMessage("Is ${marker.provider.name} available right now?")
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, "Chat Provider", modifier = Modifier.size(16.dp))
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.initiateBookingForm(marker.provider)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        contentPadding = PaddingValues(horizontal = 14.dp)
                                    ) {
                                        Text("BOOK NOW", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ℹ️ Tap on any provider radar marker to display booking specs",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B), fontWeight = FontWeight.Medium),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// --- 6. PROVIDER PROFILE SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: ServiceViewModel) {
    val provider by viewModel.selectedProvider.collectAsState()

    if (provider == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Provider Profile") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppScreen.Dashboard) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back Arrow")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Initials Badge Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .background(Color(0xFFEFF6FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = provider!!.name.split(" ").map { it.first() }.joinToString("").uppercase(),
                            color = Color(0xFF2563EB),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = provider!!.name,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)),
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = provider!!.serviceType,
                        style = MaterialTheme.typography.titleMedium.copy(color = Color(0xFF2563EB), fontWeight = FontWeight.SemiBold),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Rating block
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("★ ${provider!!.rating}", fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 18.sp)
                            Text("Rating", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF64748B)))
                        }

                        // Experience block
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${provider!!.experience} Yrs", fontWeight = FontWeight.Bold, color = Color(0xFF1E293B), fontSize = 18.sp)
                            Text("Experience", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF64748B)))
                        }

                        // Price block
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("₹${provider!!.price.toInt()}", fontWeight = FontWeight.Bold, color = Color(0xFF10B981), fontSize = 18.sp)
                            Text("Best Price", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF64748B)))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Details card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(2.dp, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Availability Support",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.HourglassEmpty, "Timer", tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = provider!!.availability,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium, color = Color(0xFF047857))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Quality Verification",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = "Every professional in the Smart Service Finder elite network has completed background validation, security screenings, and passed active functional checks to ensure absolute safety.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF64748B))
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Reviews and Ratings Section
            val reviews by viewModel.currentProviderReviews.collectAsState()
            val isEligible by viewModel.isEligibleToReview.collectAsState()
            val ratingState by viewModel.reviewRating.collectAsState()
            val commentState by viewModel.reviewComment.collectAsState()
            val submitError by viewModel.reviewSubmitError.collectAsState()

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(2.dp, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Customer Reviews & Ratings",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFFFBEB))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "★ ${provider!!.rating}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (reviews.isEmpty()) {
                        Text(
                            "No reviews yet. Be the first to leave a review after your service is completed!",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF64748B)),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        // Display reviews
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            reviews.forEach { review ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = review.userName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF1E293B)
                                        )
                                        Row {
                                            (1..5).forEach { starIdx ->
                                                Icon(
                                                    imageVector = Icons.Default.Star,
                                                    contentDescription = null,
                                                    tint = if (starIdx <= review.rating) Color(0xFFF59E0B) else Color(0xFFE2E8F0),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(4.dp))
                                    
                                    Text(
                                        text = review.comment,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF475569))
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                                    Text(
                                        text = sdf.format(Date(review.timestamp)),
                                        fontSize = 10.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 16.dp), color = Color(0xFFE2E8F0))

                    // Submit rating feature
                    if (isEligible) {
                        Text(
                            "Share Your Experience",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Your Rating: ", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF475569))
                            Spacer(modifier = Modifier.width(8.dp))
                            Row {
                                (1..5).forEach { i ->
                                    IconButton(
                                        onClick = { viewModel.reviewRating.value = i.toFloat() },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "Star $i",
                                            tint = if (i <= ratingState) Color(0xFFF59E0B) else Color(0xFFCBD5E1),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = commentState,
                            onValueChange = { viewModel.reviewComment.value = it },
                            placeholder = { Text("Write your review comment here...", fontSize = 14.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .testTag("review_comment_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (submitError.isNotBlank()) {
                            Text(
                                text = submitError,
                                color = Color.Red,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.submitReview() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("submit_review_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                        ) {
                            Text("Submit Review", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Info",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Only verified customers with a 'Completed' service booking with this provider can leave a rating & review.",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B),
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Action Buttons
            Button(
                onClick = { viewModel.initiateBookingForm(provider!!) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("book_service_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Icon(Icons.Default.CheckCircle, "Book Provider")
                Spacer(modifier = Modifier.width(10.dp))
                Text("Schedule & Book Visit", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            OutlinedButton(
                onClick = {
                    viewModel.navigateTo(AppScreen.Chat)
                    viewModel.sendChatMessage("I want to know if ${provider!!.name} can do a customized house visit tomorrow?")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, "Ask AI Helper")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Discuss with AI Assistant", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- 7. BOOKING FORM SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookScreen(viewModel: ServiceViewModel) {
    val provider by viewModel.selectedProvider.collectAsState()
    val date by viewModel.bookingDate.collectAsState()
    val timeSlot by viewModel.bookingTimeSlot.collectAsState()
    val address by viewModel.bookingAddress.collectAsState()
    val notes by viewModel.bookingNotes.collectAsState()
    val errorCompletedMsg by viewModel.bookingCompletedMessage.collectAsState()

    if (provider == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Booking Confirmation") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(AppScreen.Profile) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back Arrow")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(24.dp)
        ) {
            // Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Receipt, "Receipt Icon", tint = Color(0xFF2563EB), modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("You are booking", style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF2563EB)))
                        Text(provider!!.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)))
                        Text("${provider!!.serviceType} • Visit rate: ₹${provider!!.price.toInt()}", style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF475569)))
                    }
                }
            }

            // Input Fields Form
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Schedule Details",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF1E293B)),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = date,
                        onValueChange = { viewModel.bookingDate.value = it },
                        label = { Text("Service Date (YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Default.DateRange, "Date Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_date_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = timeSlot,
                        onValueChange = { viewModel.bookingTimeSlot.value = it },
                        label = { Text("Available Time Slot") },
                        leadingIcon = { Icon(Icons.Default.AccessTime, "Time Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_timeslot_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = address,
                        onValueChange = { viewModel.bookingAddress.value = it },
                        label = { Text("Contact Info & Billing Address") },
                        leadingIcon = { Icon(Icons.Default.Home, "Address Pin") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_address_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { viewModel.bookingNotes.value = it },
                        label = { Text("Special Instructions (Optional)") },
                        leadingIcon = { Icon(Icons.Default.EditNote, "Notes Icon") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_notes_input"),
                        maxLines = 3
                    )

                    if (errorCompletedMsg.isNotEmpty()) {
                        Text(
                            text = errorCompletedMsg,
                            color = if (errorCompletedMsg.contains("confirmed")) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { viewModel.confirmBooking() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("confirm_booking_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                    ) {
                        Text("Confirm Booking Request", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

// --- 8. BOOKING HISTORY ---
@Composable
fun HistoryScreen(viewModel: ServiceViewModel) {
    val bookings by viewModel.myBookings.collectAsState()
    val providers by viewModel.allProviders.collectAsState()

    var selectedTab by remember { mutableStateOf("Pending") } // Pending, Completed, Cancelled tabs

    Scaffold(
        bottomBar = { AppBottomNavigation(AppScreen.History) { viewModel.navigateTo(it) } }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(innerPadding)
        ) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B))
                    .padding(horizontal = 24.dp, vertical = 20.dp)
            ) {
                Column {
                    Text("My Service Trackings", style = MaterialTheme.typography.headlineSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    Text("Manage pending schedules & completions", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.7f)))
                }
            }

            // Tab Rows
            TabRow(
                selectedTabIndex = when (selectedTab) {
                    "Pending" -> 0
                    "Completed" -> 1
                    else -> 2
                },
                containerColor = Color.White
            ) {
                Tab(
                    selected = selectedTab == "Pending",
                    onClick = { selectedTab = "Pending" },
                    text = { Text("Pending Schedule", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == "Completed",
                    onClick = { selectedTab = "Completed" },
                    text = { Text("Completed Visits", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == "Cancelled",
                    onClick = { selectedTab = "Cancelled" },
                    text = { Text("Cancelled", fontWeight = FontWeight.Bold) }
                )
            }

            // Bookings List filter
            val filteredBookings = bookings.filter { it.bookingStatus.equals(selectedTab, ignoreCase = true) }

            if (filteredBookings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, "Empty History", modifier = Modifier.size(56.dp), tint = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No orders in $selectedTab state", color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredBookings) { booking ->
                        val p = providers.find { it.id == booking.providerId } ?: Provider(
                            name = "Verified Specialist", serviceType = "Support Service", rating = 4.5, experience = 5, latitude = 0.0, longitude = 0.0, availability = "Unknown", price = 300.0
                        )

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(1.dp, RoundedCornerShape(14.dp))
                                .testTag("booking_history_card_${booking.id}"),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(p.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                        Text("${p.serviceType} • Visit fee: ₹${p.price.toInt()}", style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B)))
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                when (selectedTab) {
                                                    "Pending" -> Color(0xFFFEF3C7)
                                                    "Completed" -> Color(0xFFECFDF5)
                                                    else -> Color(0xFFFEE2E2)
                                                }
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = booking.bookingStatus,
                                            fontSize = 11.sp,
                                            color = when (selectedTab) {
                                                "Pending" -> Color(0xFFB45309)
                                                "Completed" -> Color(0xFF047857)
                                                else -> Color(0xFFB91C1C)
                                            },
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFF1F5F9))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.DateRange, "Date info", modifier = Modifier.size(14.dp), tint = Color(0xFF94A3B8))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(booking.bookingDate, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AccessTime, "Time info", modifier = Modifier.size(14.dp), tint = Color(0xFF94A3B8))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(booking.timeSlot, style = MaterialTheme.typography.bodySmall, color = Color(0xFF475569))
                                        }
                                    }

                                    // Action buttons for cancel or complete bookings pending
                                    if (selectedTab == "Pending") {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(
                                                onClick = { viewModel.updateBookingStatus(booking.id, "Cancelled") },
                                                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444)),
                                                modifier = Modifier.testTag("cancel_booking_btn_${booking.id}")
                                            ) {
                                                Text("Cancel", fontWeight = FontWeight.Bold)
                                            }
                                            Button(
                                                onClick = { viewModel.updateBookingStatus(booking.id, "Completed") },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.testTag("complete_booking_btn_${booking.id}")
                                            ) {
                                                Text("Finish Visit", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }

                                // Interactive Push Notification Backend Simulator Console for Key Events
                                if (selectedTab == "Pending") {
                                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFF1F5F9))
                                    Column(
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Build,
                                                contentDescription = "Simulator Control",
                                                tint = Color(0xFF2563EB),
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "BACKEND TEST CONTROLS (FCM SIMULATOR)",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF2563EB),
                                                letterSpacing = 0.5.sp
                                            )
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Sim Arrival
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFFEFF6FF))
                                                    .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(10.dp))
                                                    .clickable { viewModel.simulateProviderArrival(booking.id) }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.MyLocation, "Arrival", tint = Color(0xFF2563EB), modifier = Modifier.size(11.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Sim Arrival", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB))
                                                }
                                            }

                                            // Sim Message
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFFECFDF5))
                                                    .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(10.dp))
                                                    .clickable { viewModel.simulateIncomingMessage(booking.id, "Hi, I have all my tools and am arriving shortly.") }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Send, "Message", tint = Color(0xFF059669), modifier = Modifier.size(11.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Sim Message", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                                                }
                                            }

                                            // Sim Completion
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFFFFFBEB))
                                                    .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(10.dp))
                                                    .clickable { viewModel.simulateServiceCompletion(booking.id) }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.CheckCircle, "Completed", tint = Color(0xFFD97706), modifier = Modifier.size(11.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Sim Complete", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 9. AI COMPANION SUPPORT ASSISTANT SCREEN ---
@Composable
fun ChatbotScreen(viewModel: ServiceViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val isLoading by viewModel.isChatLoading.collectAsState()
    val scope = rememberCoroutineScope()
    
    var textInput by remember { mutableStateOf("") }
    val keyboard = LocalSoftwareKeyboardController.current

    Scaffold(
        bottomBar = { AppBottomNavigation(AppScreen.Chat) { viewModel.navigateTo(it) } }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF1F5F9))
                .padding(innerPadding)
        ) {
            // Header panel describing capabilities styled with modern Clean Utility accents
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .shadow(1.dp, RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0xFF2563EB).copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, "AI icon badge", tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Smart Service AI Assistant",
                            style = MaterialTheme.typography.titleSmall.copy(color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Analyzes criteria and matches recommended home bookings instantly",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B))
                        )
                    }
                    IconButton(
                        onClick = { viewModel.clearChat() },
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFF1F5F9), CircleShape)
                    ) {
                        Icon(Icons.Default.Refresh, "Clear chat", tint = Color(0xFF475569), modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Chat Messages listing
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    val alignment = if (msg.isUser) Alignment.End else Alignment.Start
                    val containerColor = if (msg.isUser) Color(0xFF2563EB) else Color.White
                    val textColor = if (msg.isUser) Color.White else Color(0xFF1E293B)
                    val shape = if (msg.isUser) {
                        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 2.dp)
                    } else {
                        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 2.dp, bottomEnd = 16.dp)
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = alignment
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = containerColor),
                            shape = shape,
                            modifier = Modifier
                                .widthIn(max = 280.dp)
                                .shadow(1.dp, shape)
                        ) {
                            Text(
                                text = msg.text,
                                modifier = Modifier.padding(14.dp),
                                style = MaterialTheme.typography.bodyMedium.copy(color = textColor, lineHeight = 20.sp),
                                textAlign = if (msg.isUser) TextAlign.End else TextAlign.Start
                            )
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Agent searches available matched services...", style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF64748B)))
                        }
                    }
                }
            }

            // Input Row panel
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Search or Book: 'plumber under ₹400'", fontSize = 14.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field"),
                        maxLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank() && !isLoading) {
                                    viewModel.sendChatMessage(textInput)
                                    textInput = ""
                                    keyboard?.hide()
                                }
                            }
                        )
                    )

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank() && !isLoading) {
                                viewModel.sendChatMessage(textInput)
                                textInput = ""
                                keyboard?.hide()
                            }
                        },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("chat_send_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, "Send button message", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
