package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    Splash,
    Login,
    Register,
    Dashboard,
    Maps,
    Profile,
    Book,
    History,
    Chat
}

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class ScoredProvider(
    val provider: Provider,
    val distance: Double, // in km
    val score: Double
)

class ServiceViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val dao = db.serviceDao()
    val repository = ServiceRepository(dao)
    private val chatbotEngine = GeminiChatbotEngine(repository)

    // Current State screen
    var currentScreen = MutableStateFlow(AppScreen.Splash)
        private set

    // Current Logged in user
    var currentUser = MutableStateFlow<User?>(null)
        private set

    // All base providers
    var allProviders = MutableStateFlow<List<Provider>>(emptyList())
        private set

    // Map selected / Active category filter
    var selectedCategory = MutableStateFlow<String?>(null)
        private set

    // Active provider chosen for profile details / booking
    var selectedProvider = MutableStateFlow<Provider?>(null)
        private set

    // User's custom current simulation location
    var userLat = MutableStateFlow(12.9716) // Bangalore center
    var userLng = MutableStateFlow(77.5946)

    // Logged user's bookings
    var myBookings = MutableStateFlow<List<Booking>>(emptyList())
        private set

    // All AI chat messages
    var chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "Hello! I am your AI Local Service Assistant. Just tell me what you need, for example:\n'Need a top rated cleaning helper today' or 'plumber under ₹350' and I'll find them and prepare your booking!",
                isUser = false
            )
        )
    )
        private set

    var isChatLoading = MutableStateFlow(false)
        private set

    var searchText = MutableStateFlow("")
        private set

    // Form inputs
    var loginEmail = MutableStateFlow("")
    var loginPassword = MutableStateFlow("")
    var loginError = MutableStateFlow("")

    var registerName = MutableStateFlow("")
    var registerEmail = MutableStateFlow("")
    var registerPhone = MutableStateFlow("")
    var registerPassword = MutableStateFlow("")
    var registerAddress = MutableStateFlow("")
    var registerError = MutableStateFlow("")

    // Booking form inputs
    var bookingDate = MutableStateFlow("")
    var bookingTimeSlot = MutableStateFlow("")
    var bookingAddress = MutableStateFlow("")
    var bookingNotes = MutableStateFlow("")
    var bookingCompletedMessage = MutableStateFlow("")

    // Active reviews state
    var currentProviderReviews = MutableStateFlow<List<Review>>(emptyList())
        private set

    // Review form inputs
    var reviewRating = MutableStateFlow(5f)
    var reviewComment = MutableStateFlow("")
    var reviewSubmitError = MutableStateFlow("")

    init {
        viewModelScope.launch {
            // Assure providers populated
            repository.allProvidersFlow.collect { list ->
                if (list.isEmpty()) {
                    repository.prepaidCheck()
                } else {
                    allProviders.value = list
                }
            }
        }

        // Auto observe bookings once user logs in
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    // Update locations
                    userLat.value = user.latitude
                    userLng.value = user.longitude
                    bookingAddress.value = user.name + ", " + user.phone
                    // Observe booking
                    repository.getBookingsForUser(user.id).collect { bookings ->
                        myBookings.value = bookings
                    }
                }
            }
        }

        // Auto load reviews when selected provider changes
        var reviewsJob: kotlinx.coroutines.Job? = null
        viewModelScope.launch {
            selectedProvider.collect { provider ->
                reviewsJob?.cancel()
                if (provider != null) {
                    reviewsJob = viewModelScope.launch {
                        repository.getReviewsForProviderFlow(provider.id).collect { list ->
                            currentProviderReviews.value = list
                        }
                    }
                } else {
                    currentProviderReviews.value = emptyList()
                }
            }
        }
    }

    val isEligibleToReview: StateFlow<Boolean> = combine(selectedProvider, myBookings) { provider, bookings ->
        if (provider == null) false
        else bookings.any { it.providerId == provider.id && it.bookingStatus == "Completed" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun submitReview() {
        val provider = selectedProvider.value ?: return
        val user = currentUser.value
        if (user == null) {
            reviewSubmitError.value = "You must be logged in to leave a review."
            return
        }
        val commentText = reviewComment.value.trim()
        if (commentText.isBlank()) {
            reviewSubmitError.value = "Please write a comment for your review."
            return
        }

        viewModelScope.launch {
            val newReview = Review(
                providerId = provider.id,
                userId = user.id,
                userName = user.name,
                rating = reviewRating.value.toDouble(),
                comment = commentText,
                timestamp = System.currentTimeMillis()
            )
            repository.insertReview(newReview)
            
            // Clear inputs
            reviewComment.value = ""
            reviewRating.value = 5f
            reviewSubmitError.value = ""
            
            // Refresh provider details to update rating display in UI
            val updatedProvider = repository.getProviderById(provider.id)
            if (updatedProvider != null) {
                selectedProvider.value = updatedProvider
                // Also update the general list
                allProviders.value = repository.getAllProviders()
            }
        }
    }

    // Recommendation Scored list based on userlat/userlng
    val scoredProviders: StateFlow<List<ScoredProvider>> = combine(
        allProviders, selectedCategory, userLat, userLng, searchText
    ) { providers, category, lat, lng, search ->
        providers.filter { provider ->
            // Category filter
            val matchesCategory = category == null || provider.serviceType.equals(category, ignoreCase = true)
            // Name / Type search filter
            val matchesSearch = search.isEmpty() || 
                    provider.name.contains(search, ignoreCase = true) || 
                    provider.serviceType.contains(search, ignoreCase = true)
            matchesCategory && matchesSearch
        }.map { provider ->
            // Calculate Euclidean distance as approximation of km
            val dLat = provider.latitude - lat
            val dLng = provider.longitude - lng
            val distance = Math.sqrt(dLat * dLat + dLng * dLng) * 111.0 // rough km scale
            
            // Formula specified in AI Recommendation Engine
            // score = rating * 0.5 + experience * 0.2 - distance * 0.3
            val score = (provider.rating * 0.5) + (provider.experience * 0.2) - (distance * 0.3)
            
            ScoredProvider(provider, distance, score)
        }.sortedByDescending { it.score }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Navigation Helper
    fun navigateTo(screen: AppScreen) {
        currentScreen.value = screen
    }

    // Search input modification
    fun onSearchChanged(newSearch: String) {
        searchText.value = newSearch
    }

    // Category Choice
    fun selectCategoryFilter(category: String?) {
        selectedCategory.value = category
    }

    // Provider Choice
    fun selectProviderForDetails(provider: Provider) {
        selectedProvider.value = provider
        bookingDate.value = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        bookingTimeSlot.value = "10:00 AM - 12:00 PM"
        navigateTo(AppScreen.Profile)
    }

    fun initiateBookingForm(provider: Provider) {
        selectedProvider.value = provider
        bookingDate.value = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        bookingTimeSlot.value = "10:00 AM - 12:00 PM"
        currentUser.value?.let {
            bookingAddress.value = registerAddress.value.ifEmpty { "Bengaluru Center, India" }
        }
        navigateTo(AppScreen.Book)
    }

    // Auth actions
    fun performLogin() {
        if (loginEmail.value.isBlank() || loginPassword.value.isBlank()) {
            loginError.value = "Email and Password cannot be blank"
            return
        }

        viewModelScope.launch {
            val user = repository.loginUser(loginEmail.value, loginPassword.value)
            if (user != null) {
                currentUser.value = user
                loginError.value = ""
                navigateTo(AppScreen.Dashboard)
            } else {
                loginError.value = "Invalid email or password"
            }
        }
    }

    fun performRegister() {
        if (registerName.value.isBlank() || registerEmail.value.isBlank() || 
            registerPhone.value.isBlank() || registerPassword.value.isBlank()
        ) {
            registerError.value = "All fields are required"
            return
        }

        viewModelScope.launch {
            val newUser = User(
                name = registerName.value,
                email = registerEmail.value,
                phone = registerPhone.value,
                password = registerPassword.value,
                latitude = 12.9716 + (Math.random() - 0.5) * 0.05, // seed nearby coords
                longitude = 77.5946 + (Math.random() - 0.5) * 0.05
            )
            try {
                val rowId = repository.registerUser(newUser)
                if (rowId > 0) {
                    val userFromDb = repository.loginUser(newUser.email, newUser.password)
                    currentUser.value = userFromDb
                    registerError.value = ""
                    navigateTo(AppScreen.Dashboard)
                } else {
                    registerError.value = "Registration failed"
                }
            } catch (e: Exception) {
                registerError.value = "Error: Email might be already registered"
            }
        }
    }

    fun handleLogout() {
        currentUser.value = null
        loginEmail.value = ""
        loginPassword.value = ""
        navigateTo(AppScreen.Login)
    }

    // Update location simulated by maps dragging
    fun updateUserCoordinates(lat: Double, lng: Double) {
        userLat.value = lat
        userLng.value = lng
        currentUser.value?.let { user ->
            viewModelScope.launch {
                repository.updateUserLocation(user.id, lat, lng)
                currentUser.value = user.copy(latitude = lat, longitude = lng)
            }
        }
    }

    // Create a Booking
    fun confirmBooking() {
        val user = currentUser.value
        val provider = selectedProvider.value
        if (user == null || provider == null) return

        if (bookingDate.value.isBlank() || bookingTimeSlot.value.isBlank() || bookingAddress.value.isBlank()) {
            bookingCompletedMessage.value = "Please fill in Date, Slot, and Address fields"
            return
        }

        viewModelScope.launch {
            val booking = Booking(
                userId = user.id,
                providerId = provider.id,
                bookingDate = bookingDate.value,
                timeSlot = bookingTimeSlot.value,
                address = bookingAddress.value,
                notes = bookingNotes.value,
                bookingStatus = "Pending"
            )
            val bookingId = repository.createBooking(booking)
            if (bookingId > 0) {
                bookingCompletedMessage.value = "Booking confirmed with ${provider.name}!"
                bookingNotes.value = ""
                
                // Immediately trigger simulated backend push notification
                NotificationBackendSimulator.dispatchBookingConfirmation(
                    getApplication(),
                    bookingId.toInt(),
                    provider.name,
                    bookingDate.value,
                    bookingTimeSlot.value
                )
                
                // Auto navigate back to dashboard/history
                navigateTo(AppScreen.History)
            } else {
                bookingCompletedMessage.value = "Failed to secure booking."
            }
        }
    }

    // Manage Bookings
    fun updateBookingStatus(bookingId: Int, status: String) {
        viewModelScope.launch {
            repository.updateBookingStatus(bookingId, status)
            
            // Trigger push notifications on status updates
            val booking = myBookings.value.find { it.id == bookingId }
            if (booking != null) {
                val providerName = allProviders.value.find { it.id == booking.providerId }?.name ?: "Specialist"
                if (status == "Completed") {
                    NotificationBackendSimulator.dispatchServiceCompletion(getApplication(), bookingId, providerName)
                } else if (status == "Cancelled") {
                    NotificationHelper.createSystemNotification(
                        getApplication(),
                        "Booking Cancelled ℹ️",
                        "Your booking with $providerName has been cancelled.",
                        "History"
                    )
                }
            }
        }
    }

    // --- PUSH NOTIFICATION SIMULATOR EVENTS ---
    fun simulateProviderArrival(bookingId: Int) {
        viewModelScope.launch {
            val booking = myBookings.value.find { it.id == bookingId } ?: return@launch
            val provider = allProviders.value.find { it.id == booking.providerId } ?: return@launch
            
            NotificationBackendSimulator.dispatchProviderArrival(getApplication(), bookingId, provider.name)
        }
    }

    fun simulateIncomingMessage(bookingId: Int, messageText: String) {
        viewModelScope.launch {
            val booking = myBookings.value.find { it.id == bookingId } ?: return@launch
            val provider = allProviders.value.find { it.id == booking.providerId } ?: return@launch
            
            // Connect incoming message notification to active chat list state!
            val providerMsg = ChatMessage(
                text = "[Message from ${provider.name}]: $messageText",
                isUser = false
            )
            chatMessages.value = chatMessages.value + providerMsg
            
            NotificationBackendSimulator.dispatchMessageFromProvider(getApplication(), bookingId, provider.name, messageText)
        }
    }

    fun simulateServiceCompletion(bookingId: Int) {
        viewModelScope.launch {
            val booking = myBookings.value.find { it.id == bookingId } ?: return@launch
            val provider = allProviders.value.find { it.id == booking.providerId } ?: return@launch
            
            // Update the state & database
            repository.updateBookingStatus(bookingId, "Completed")
            
            NotificationBackendSimulator.dispatchServiceCompletion(getApplication(), bookingId, provider.name)
        }
    }

    // AI Chatbot agent logic
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return

        val trimmed = text.trim()
        val userMsg = ChatMessage(text = trimmed, isUser = true)
        val updated = chatMessages.value + userMsg
        chatMessages.value = updated

        isChatLoading.value = true

        viewModelScope.launch {
            try {
                // Generate reply using AI/fallback engine
                val response = chatbotEngine.generateAiResponse(trimmed)
                
                val aiMsg = ChatMessage(text = response.replyText, isUser = false)
                chatMessages.value = chatMessages.value + aiMsg

                // If a recommended provider has been targeted, update state
                if (response.recommendedProviderId != null) {
                    val matching = allProviders.value.find { it.id == response.recommendedProviderId }
                    if (matching != null) {
                        selectedProvider.value = matching
                    }
                }

                // If AI suggests auto booking activation, forward user to booking or profile
                if (response.suggestBooking && response.recommendedProviderId != null) {
                    val matching = allProviders.value.find { it.id == response.recommendedProviderId }
                    if (matching != null) {
                        selectedProvider.value = matching
                        bookingDate.value = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        bookingTimeSlot.value = "10:00 AM - 12:00 PM"
                        navigateTo(AppScreen.Book)
                    }
                }
            } catch (e: Exception) {
                val errorMsg = ChatMessage(text = "Apologies, I encountered an issue: ${e.message}. Please try again.", isUser = false)
                chatMessages.value = chatMessages.value + errorMsg
            } finally {
                isChatLoading.value = false
            }
        }
    }

    fun clearChat() {
        chatMessages.value = listOf(
            ChatMessage(
                text = "Hello! I am your AI Local Service Assistant. Just tell me what you need, for example:\n'Need a top rated cleaning helper today' or 'plumber under ₹350' and I'll find them and prepare your booking!",
                isUser = false
            )
        )
    }
}
