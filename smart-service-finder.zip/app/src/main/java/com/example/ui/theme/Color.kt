package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF2563EB)
val GreenSecondary = Color(0xFF10B981)
val BackgroundLight = Color(0xFFF8FAFC)
val AccentAmber = Color(0xFFF59E0B)

val Slate800 = Color(0xFF1E293B)
val Slate600 = Color(0xFF475569)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

