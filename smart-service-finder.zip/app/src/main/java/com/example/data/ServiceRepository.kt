package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ServiceRepository(private val dao: ServiceDao) {

    val allProvidersFlow: Flow<List<Provider>> = dao.getAllProvidersFlow()

    suspend fun prepaidCheck() {
        val count = dao.getAllProviders().size
        if (count == 0) {
            val defaults = listOf(
                Provider(
                    name = "Ramesh Kumar",
                    serviceType = "Electrician",
                    rating = 4.8,
                    experience = 10,
                    latitude = 12.9780,
                    longitude = 77.5990,
                    availability = "Available Today",
                    price = 349.0
                ),
                Provider(
                    name = "Alok Sharma",
                    serviceType = "Electrician",
                    rating = 4.2,
                    experience = 5,
                    latitude = 12.9650,
                    longitude = 77.5850,
                    availability = "Available Tomorrow",
                    price = 299.0
                ),
                Provider(
                    name = "Suresh Patil",
                    serviceType = "Plumber",
                    rating = 4.7,
                    experience = 8,
                    latitude = 12.9810,
                    longitude = 77.5890,
                    availability = "Available Today",
                    price = 399.0
                ),
                Provider(
                    name = "John Fernandes",
                    serviceType = "Plumber",
                    rating = 4.5,
                    experience = 4,
                    latitude = 12.9620,
                    longitude = 77.6010,
                    availability = "Available Today",
                    price = 249.0
                ),
                Provider(
                    name = "Vikram Singh",
                    serviceType = "Carpenter",
                    rating = 4.9,
                    experience = 12,
                    latitude = 12.9740,
                    longitude = 77.6100,
                    availability = "Available Tomorrow",
                    price = 499.0
                ),
                Provider(
                    name = "Asif AC Tech",
                    serviceType = "AC Repair",
                    rating = 4.6,
                    experience = 6,
                    latitude = 12.9550,
                    longitude = 77.5900,
                    availability = "Available Today",
                    price = 450.0
                ),
                Provider(
                    name = "Rajesh AC Repair",
                    serviceType = "AC Repair",
                    rating = 3.9,
                    experience = 3,
                    latitude = 12.9900,
                    longitude = 77.5920,
                    availability = "Available Today",
                    price = 399.0
                ),
                Provider(
                    name = "Gopal Prasad",
                    serviceType = "Painter",
                    rating = 4.4,
                    experience = 7,
                    latitude = 12.9690,
                    longitude = 77.5750,
                    availability = "Available Today",
                    price = 599.0
                ),
                Provider(
                    name = "Anita Shinde Cleaner",
                    serviceType = "Cleaning",
                    rating = 4.8,
                    experience = 9,
                    latitude = 12.9720,
                    longitude = 77.6040,
                    availability = "Available Today",
                    price = 499.0
                ),
                Provider(
                    name = "Sparkle Cleaning Ltd",
                    serviceType = "Cleaning",
                    rating = 4.1,
                    experience = 2,
                    latitude = 12.9510,
                    longitude = 77.6120,
                    availability = "Busy Today",
                    price = 349.0
                )
            )
            dao.insertProviders(defaults)
            
            // Seed beautiful reviews for Ramesh, Alok, Suresh, and Anita
            val defaultReviews = listOf(
                Review(providerId = 1, userId = 101, userName = "Vikram Aditya", rating = 5.0, comment = "Excellent work. Ramesh arrived within 30 minutes, diagnosed the short circuit in our main DB board, and proposed the most safety-compliant repair. Absolute expert!"),
                Review(providerId = 1, userId = 102, userName = "Sneha Mehta", rating = 4.0, comment = "Very knowledgeable electrician, though price is slightly on the premium side. Job was completed cleanly and safely."),
                Review(providerId = 3, userId = 103, userName = "Varun Kapoor", rating = 5.0, comment = "Superb service. Suresh resolved a severe kitchen pipe blockage in just under 20 minutes! Left the workspace absolutely spotless."),
                Review(providerId = 9, userId = 104, userName = "Deepa G.", rating = 5.0, comment = "Anita is incredibly efficient and friendly. She did a thorough deep cleaning of our entire kitchen including the chimney grease removal. Highly recommended!")
            )
            for (rev in defaultReviews) {
                dao.insertReview(rev)
            }
        }
    }

    suspend fun loginUser(email: String, password: String): User? {
        return dao.loginUser(email, password)
    }

    suspend fun registerUser(user: User): Long {
        return dao.registerUser(user)
    }

    suspend fun getUserById(id: Int): User? {
        return dao.getUserById(id)
    }

    suspend fun updateUserLocation(userId: Int, lat: Double, lng: Double) {
        dao.updateUserLocation(userId, lat, lng)
    }

    suspend fun getAllProviders(): List<Provider> {
        prepaidCheck()
        return dao.getAllProviders()
    }

    suspend fun getProvidersByCategory(serviceType: String): List<Provider> {
        prepaidCheck()
        return dao.getProvidersByCategory(serviceType)
    }

    suspend fun getProviderById(id: Int): Provider? {
        return dao.getProviderById(id)
    }

    fun getBookingsForUser(userId: Int): Flow<List<Booking>> {
        return dao.getBookingsForUserFlow(userId)
    }

    fun getAllBookingsFlow(): Flow<List<Booking>> {
        return dao.getAllBookingsFlow()
    }

    suspend fun createBooking(booking: Booking): Long {
        return dao.createBooking(booking)
    }

    suspend fun updateBookingStatus(bookingId: Int, status: String) {
        dao.updateBookingStatus(bookingId, status)
    }

    fun getReviewsForProviderFlow(providerId: Int): Flow<List<Review>> {
        return dao.getReviewsForProviderFlow(providerId)
    }

    suspend fun getReviewsForProvider(providerId: Int): List<Review> {
        return dao.getReviewsForProvider(providerId)
    }

    suspend fun insertReview(review: Review): Long {
        val result = dao.insertReview(review)
        val reviews = dao.getReviewsForProvider(review.providerId)
        if (reviews.isNotEmpty()) {
            val avg = reviews.map { it.rating }.average()
            val rounded = Math.round(avg * 10.0) / 10.0
            dao.updateProviderRating(review.providerId, rounded)
        }
        return result
    }
}
