package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseFormat: ResponseFormat? = null,
    val temperature: Float? = null,
    val maxOutputTokens: Int? = null
)

@JsonClass(generateAdapter = true)
data class ResponseFormat(
    val type: String // "application/json" or "text/plain"
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

@JsonClass(generateAdapter = true)
data class ChatbotResponse(
    val replyText: String,
    val recommendedProviderId: Int? = null,
    val suggestBooking: Boolean = false
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

class GeminiChatbotEngine(private val repository: ServiceRepository) {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
    private val responseAdapter = moshi.adapter(ChatbotResponse::class.java)

    suspend fun generateAiResponse(userMessage: String): ChatbotResponse {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // Fetch current active list of providers to inject context to Gemini
        val providers = repository.getAllProviders()
        val providerContextText = providers.joinToString("\n") {
            "- ID: ${it.id}, Name: ${it.name}, Type: ${it.serviceType}, Rating: ${it.rating}, Experience: ${it.experience} Years, Price: ₹${it.price.toInt()}, Location: (${it.latitude}, ${it.longitude}), Availability: ${it.availability}"
        }

        val prompt = """
            User message: "$userMessage"
            
            Current available service providers:
            $providerContextText
            
            Based on the user's message, perform these actions:
            1. Respond in a friendly, conversational assistant tone (Urban Company style).
            2. Check if the user is asking for a specific service type (Electrician, Plumber, Carpenter, AC Repair, Painter, Cleaning).
            3. Recommend the best matching provider based on:
               - Their requested criteria (e.g., under ₹500, specific type, high experience).
               - If rating or budget is mentioned, prioritize that.
            4. If a strong match is found, output its ID as `recommendedProviderId`.
            5. In the final message, write clear booking recommendations.
            
            You MUST return a JSON object with this exact structure:
            {
               "replyText": "convincing explanation and recommendation",
               "recommendedProviderId": 123 (or null if none match),
               "suggestBooking": true/false
            }
        """.trimIndent()

        // Fallback rule-based helper (if API key is missing, or is default/placeholder)
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY") {
            return generateRuleBasedResponse(userMessage, providers)
        }

        return try {
            val systemInstruction = "You are a local home service coordinator bot. You return JSON formatted responses for local service queries."
            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                generationConfig = GenerationConfig(
                    responseFormat = ResponseFormat(type = "application/json"),
                    temperature = 0.2f
                ),
                systemInstruction = Content(parts = listOf(Part(text = systemInstruction)))
            )
            val result = RetrofitClient.service.generateContent(apiKey, request)
            val rawJsonText = result.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw Exception("Empty response candidate")

            // Parse response
            val parsed = responseAdapter.fromJson(rawJsonText)
                ?: throw Exception("Failed to parse chatbot response JSON")
            parsed
        } catch (e: Exception) {
            // Graceful fallback to rule-based engine on any error/timeout
            generateRuleBasedResponse(userMessage, providers, errorPrefix = "")
        }
    }

    private fun generateRuleBasedResponse(
        message: String,
        providers: List<Provider>,
        errorPrefix: String = ""
    ): ChatbotResponse {
        val lowerMessage = message.lowercase()
        
        // Find Category
        val category = when {
            lowerMessage.contains("electric") -> "Electrician"
            lowerMessage.contains("plumb") -> "Plumber"
            lowerMessage.contains("carpent") -> "Carpenter"
            lowerMessage.contains("ac") || lowerMessage.contains("air condition") -> "AC Repair"
            lowerMessage.contains("paint") -> "Painter"
            lowerMessage.contains("clean") || lowerMessage.contains("sweep") -> "Cleaning"
            else -> null
        }

        // Budget filters
        var maxBudget = Double.MAX_VALUE
        val budgetRegex = """under\s*(?:₹|rs\.?|inr)?\s*(\d+)""".toRegex()
        val budgetMatch = budgetRegex.find(lowerMessage)
        if (budgetMatch != null) {
            maxBudget = budgetMatch.groupValues[1].toDoubleOrNull() ?: Double.MAX_VALUE
        }

        var candidates = if (category != null) {
            providers.filter { it.serviceType.equals(category, ignoreCase = true) }
        } else {
            providers
        }

        if (maxBudget < Double.MAX_VALUE) {
            candidates = candidates.filter { it.price <= maxBudget }
        }

        // Score them and sort
        val recommended = candidates.maxByOrNull { provider ->
            provider.rating * 0.5 + provider.experience * 0.2
        }

        return if (recommended != null) {
            val budgetLimit = if (maxBudget < Double.MAX_VALUE) maxBudget.toInt() else 0
            val reply = buildString {
                if (errorPrefix.isNotEmpty()) {
                    append(errorPrefix).append("\n\n")
                }
                append("I found a great match for you! **${recommended.name}** is a highly-rated **${recommended.serviceType}** with **${recommended.experience} years of experience** ")
                append("and is ${recommended.availability.lowercase()} charging ₹${recommended.price.toInt()}. ")
                if (budgetLimit > 0) {
                    append("This fully fits your budget of under ₹$budgetLimit!")
                } else {
                    append("They have an excellent rating of ★${recommended.rating}.")
                }
                append("\n\nWould you like me to book their services for you?")
            }
            ChatbotResponse(
                replyText = reply,
                recommendedProviderId = recommended.id,
                suggestBooking = lowerMessage.contains("book") || lowerMessage.contains("schedule") || lowerMessage.contains("need") || lowerMessage.contains("want")
            )
        } else {
            val budgetLimit = if (maxBudget < Double.MAX_VALUE) maxBudget.toInt() else 0
            val replyText = if (category != null) {
                if (budgetLimit > 0) {
                    "I couldn't find any ${category}s matching your budget of under ₹$budgetLimit. Could you please adjust your budget limit?"
                } else {
                    "I couldn't find any available ${category}s at the moment. Please update the filters or choose another category."
                }
            } else {
                "Hello! I am your Smart Service Assistant. You can type queries like:\n- 'I need an electrician tomorrow morning under ₹500'\n- 'Find me the best plumber'\nHow can I help you keep your home in top shape today?"
            }
            ChatbotResponse(
                replyText = replyText,
                recommendedProviderId = null,
                suggestBooking = false
            )
        }
    }
}
