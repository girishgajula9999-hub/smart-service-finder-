package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val email: String,
    val phone: String,
    val password: String,
    val latitude: Double = 12.9716,
    val longitude: Double = 77.5946
)

@Entity(tableName = "providers")
data class Provider(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val serviceType: String, // "Electrician", "Plumber", "Carpenter", "AC Repair", "Painter", "Cleaning"
    val rating: Double,
    val experience: Int, // Years
    val latitude: Double,
    val longitude: Double,
    val availability: String, // "Available Today", "Available Tomorrow", "Busy"
    val price: Double, // Price per hour/visit, e.g. 450.0
    val photoUrl: String = "" // Placeholder photo or initials text
)

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val providerId: Int,
    val bookingDate: String, // YYYY-MM-DD
    val timeSlot: String, // slot details
    val address: String,
    val notes: String,
    val bookingStatus: String // "Pending", "Completed", "Cancelled"
)

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val providerId: Int,
    val userId: Int,
    val userName: String,
    val rating: Double,
    val comment: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ServiceDao {
    // Users
    @Query("SELECT * FROM users WHERE email = :email AND password = :password LIMIT 1")
    suspend fun loginUser(email: String, password: String): User?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun registerUser(user: User): Long

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Int): User?

    @Query("UPDATE users SET latitude = :lat, longitude = :lng WHERE id = :userId")
    suspend fun updateUserLocation(userId: Int, lat: Double, lng: Double)

    // Providers
    @Query("SELECT * FROM providers")
    fun getAllProvidersFlow(): Flow<List<Provider>>

    @Query("SELECT * FROM providers")
    suspend fun getAllProviders(): List<Provider>

    @Query("SELECT * FROM providers WHERE serviceType = :serviceType")
    suspend fun getProvidersByCategory(serviceType: String): List<Provider>

    @Query("SELECT * FROM providers WHERE id = :id")
    suspend fun getProviderById(id: Int): Provider?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProviders(providers: List<Provider>)

    @Query("UPDATE providers SET rating = :rating WHERE id = :providerId")
    suspend fun updateProviderRating(providerId: Int, rating: Double)

    // Bookings
    @Query("SELECT * FROM bookings WHERE userId = :userId ORDER BY id DESC")
    fun getBookingsForUserFlow(userId: Int): Flow<List<Booking>>

    @Query("SELECT * FROM bookings ORDER BY id DESC")
    fun getAllBookingsFlow(): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun createBooking(booking: Booking): Long

    @Query("UPDATE bookings SET bookingStatus = :status WHERE id = :bookingId")
    suspend fun updateBookingStatus(bookingId: Int, status: String)

    // Reviews
    @Query("SELECT * FROM reviews WHERE providerId = :providerId ORDER BY timestamp DESC")
    fun getReviewsForProviderFlow(providerId: Int): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE providerId = :providerId")
    suspend fun getReviewsForProvider(providerId: Int): List<Review>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review): Long
}

@Database(entities = [User::class, Provider::class, Booking::class, Review::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun serviceDao(): ServiceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "local_service_finder_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
