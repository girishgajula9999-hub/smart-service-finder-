package com.example

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: ServiceViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()

                // Listen to notification tap intents and automatically route user
                LaunchedEffect(intent) {
                    intent?.let {
                        val target = it.getStringExtra("target_screen")
                        if (!target.isNullOrBlank()) {
                            try {
                                val destination = AppScreen.valueOf(target)
                                viewModel.navigateTo(destination)
                            } catch (e: Exception) {
                                // Fallback
                            }
                        }
                    }
                }

                when (currentScreen) {
                    AppScreen.Splash -> SplashScreen(viewModel)
                    AppScreen.Login -> LoginScreen(viewModel)
                    AppScreen.Register -> RegisterScreen(viewModel)
                    AppScreen.Dashboard -> DashboardScreen(viewModel)
                    AppScreen.Maps -> MapScreen(viewModel)
                    AppScreen.Profile -> ProfileScreen(viewModel)
                    AppScreen.Book -> BookScreen(viewModel)
                    AppScreen.History -> HistoryScreen(viewModel)
                    AppScreen.Chat -> ChatbotScreen(viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Set the new intent so that LaunchedEffect captures it and updates navigation
        setIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        // Request runtime permission for push notification on Android 13+ (API 33)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    "android.permission.POST_NOTIFICATIONS"
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf("android.permission.POST_NOTIFICATIONS"),
                    101
                )
            }
        }
    }
}
